<?php include __DIR__ . '/includes/header.php'; ?>
<?php include __DIR__ . '/includes/contacto.php'; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>