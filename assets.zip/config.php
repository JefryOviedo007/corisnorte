<?php
// Configuración de la base de datos
$host = "localhost";
$user = "feceacbc_corisnorte";
$password = "%.@4(8fW?.}h";
$dbname = "feceacbc_corisnorte";

// ==========================================
// Conexión con PDO (para módulos nuevos)
// ==========================================
try {
    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    
    $pdo = new PDO($dsn, $user, $password, $options);
    
} catch (PDOException $e) {
    die("Error de conexión PDO: " . $e->getMessage());
}

// ==========================================
// Conexión con MySQLi (para compatibilidad)
// ==========================================
$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Error de conexión MySQLi: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

// ==========================================
// Variables disponibles globalmente:
// - $pdo  (PDO)
// - $conn (MySQLi)
// ==========================================
?>